enum UserType {
  customer,
  admin,
  deliveryMan,
}