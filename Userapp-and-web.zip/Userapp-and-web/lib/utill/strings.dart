class Strings {
  static const String choose_the_language = 'Choose the language';
  static const String find_language = 'Find Language';
  static const String english = 'English';
  static const String germany = 'Germany';
  static const String korean = 'Korean';
  static const String italian = 'Italian';
  static const String chinese = 'Chinese';
  static const String japanese = 'Japanese';
  static const String arabic = 'Arabic';
  static const String save = 'Save';
  static const String skip = 'Skip';
  static const String next = 'Next';
  static const String previous = 'Previous';
  static const String lets_start = 'Let\'s Start';
  static const String welcome = 'Welcome';
  static const String lorem__ipsm__nonu = 'Lorem ipsum dolor sit amet, consetetur the sadipscing elitr, sed diam nonu.';
  static const String login = 'Login';
  static const String signup = 'Singup';
  static const String mobile_number = 'Mobile Number';
  static const String enter_mobile_number = 'Enter Mobile Number';
  static const String password = 'Password';
  static const String remember_me = 'Remember me';
  static const String forgot_password = 'Forgot passoword ?';
  static const String create_an_account = 'Create an Account ?';
}